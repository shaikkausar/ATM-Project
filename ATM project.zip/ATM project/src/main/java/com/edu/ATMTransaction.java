package com.edu;

import java.util.Scanner;

public class ATMTransaction {

	public static void main(String[] args) {
		
      int balance = 50000,withdraw = 0,deposit;
      Scanner sc=new Scanner(System.in);
      
      while(true) {
    	  
    	  System.out.println("Automated teller machine");
    	  System.out.println("choose 1 for withdraw");
    	  System.out.println("choose 2 for deposit");
    	  System.out.println("choose 3 for check balance");
    	  System.out.println("choose 4 for exit");
    	  System.out.println("choose operation what you want");
    	  int n=sc.nextInt();
    	  
    	  switch(n) {
    	  
    	  case 1:
    		  System.out.println("Enter money to be withdraw:");
    		  if(balance>=withdraw) {
    			  
    			  balance =balance-withdraw;
    			  System.out.println("please collect your money");
    			  
    		  }
    		  else {
    			  System.out.println("insufficient money");
    		  }
    		  System.out.println(" ");
    		  break;
    		  
    	  case 2:
    		  System.out.println("enter money to be deposit:");
    		  deposit=sc.nextInt();
    		  balance=balance+deposit;
    	      System.out.println("your money sucessfully deposited");
    	      System.out.println(" ");
    	      break;
    	      
    	  case 3:
    		  System.out.println("Balance:"+balance);
    		  System.out.println(" ");
    		  break;
    		  
    	  case 4:
    		  System.out.println("exit");
    		  
    	  }
      }
	}

}
